#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OpenCC::OpenCC" for configuration "Release"
set_property(TARGET OpenCC::OpenCC APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenCC::OpenCC PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/tmp/build-via-sdist-3nxq_gbp/opencc-1.1.9/build/lib.linux-x86_64-cpython-312/opencc/clib/lib/libopencc.a"
  )

list(APPEND _cmake_import_check_targets OpenCC::OpenCC )
list(APPEND _cmake_import_check_files_for_OpenCC::OpenCC "/tmp/build-via-sdist-3nxq_gbp/opencc-1.1.9/build/lib.linux-x86_64-cpython-312/opencc/clib/lib/libopencc.a" )

# Import target "OpenCC::marisa" for configuration "Release"
set_property(TARGET OpenCC::marisa APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(OpenCC::marisa PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/tmp/build-via-sdist-3nxq_gbp/opencc-1.1.9/build/lib.linux-x86_64-cpython-312/opencc/clib/lib/libmarisa.a"
  )

list(APPEND _cmake_import_check_targets OpenCC::marisa )
list(APPEND _cmake_import_check_files_for_OpenCC::marisa "/tmp/build-via-sdist-3nxq_gbp/opencc-1.1.9/build/lib.linux-x86_64-cpython-312/opencc/clib/lib/libmarisa.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
